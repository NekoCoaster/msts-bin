Instalace

1) Rozbalte archiv kamkoliv na v� pevn� disk
2) Pokud m�te nainstalov�nu p�edchoz� verzi Patche, odinstalujte ji, nebo pou�ijte �istou instalaci MSTS s origin�ln�m update ver 1.4 od MS
   Po odinstalov�n� mus� b�t smaz�n adres�� "MSTSBIN_BACKUP", pokud nen�, vyma�te jej ru�n�.
3) Spust�te soubor Patch 1.8.010516.exe a �i�te se pokyny
4) Pokud pou��v�te RAILDRIVER pou�ijte dll knihovny z adres��e "Rail Driver DLLs" 

Pokud chcete pou��novat Screens a Widgets, nainstalujte nejprve Patch a teprve 
pot� nov� Screeny.
Screens instal�tor nevytv��� z�lohu, z�lohujte si proto cel� adres�� "GUI", 
pokud chcete v budoucnu obnovit p�vodn� nastaven�.
*****************************************************************
How to install

1) Unpack archiv to any place to your HD
2) If you have previous version of Patch installed, uninstall it or use clear MSTS install with original update 1.4 from MS installed.
   Afret uninstall folder "MSTSBIN_BACKUP" should be deleted, if no, delete it manualy.
3) Start Patch 1.8.010516.exe and follow instructions
4) From new "DLLs" subfolder in root of game choose your language folder and copy string.dll and dialog.dll and copy them into root of game. Confirm replace original ones.
5) If you are using RAILDRIVER, use	dlls from "Rail Driver DLLs" folder.	

If you can use new screens and widgets, install Patch first and new screens 
after. Screens instalator doesn't make backup, use manual "GUI" folder backup if 
you could restore it later. 